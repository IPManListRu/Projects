<nav>
   <a href="index.php">Главная</a>
   <a href="https://webistore.ru/internet/universalnye-atributy-tegov-v-html/"
      title="Универсальные атрибуты тегов в HTML">Атрибуты тегов</a>
   <a>Мое веб-приложение на flask</a>
   <a href="https://skillfactory.ru/"
      title="SkillFactory.ru">Контакты</a>
   <a>О разработчике</a>
</nav>      