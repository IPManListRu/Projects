<?php 
     $p = 'Приветствую Вас на моей страничке!';
?>
<?php
    $name='Иван';
    $lastname = 'Петрович';
    $surname='Манылов';
    $syti='Киров';
    $age='52';
?>
<?php
    include 'main.php';
?>